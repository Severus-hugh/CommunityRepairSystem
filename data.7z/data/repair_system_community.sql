INSERT INTO repair_system.community (communityId, communityName, communityAddress, startTime, finishTime) VALUES (12210000, '凤南小区', '六合区凤南街与湖滨路交汇1', '2008-01-14 00:00:00', '2012-04-30 00:00:00');
INSERT INTO repair_system.community (communityId, communityName, communityAddress, startTime, finishTime) VALUES (12220001, '湖滨小区(南区)', '六合区湖滨路12号', '2009-05-01 00:00:00', null);
INSERT INTO repair_system.community (communityId, communityName, communityAddress, startTime, finishTime) VALUES (12220002, '湖滨小区(北区)', '六合区', '2009-05-01 00:00:00', null);
INSERT INTO repair_system.community (communityId, communityName, communityAddress, startTime, finishTime) VALUES (13320000, '凤凰花园', '浦口区文昌路10号', '2010-06-01 00:00:00', '2019-12-30 00:00:00');
INSERT INTO repair_system.community (communityId, communityName, communityAddress, startTime, finishTime) VALUES (13330000, '金域蓝湾', '江宁区清水亭东路9号', '2021-07-01 00:00:00', null);
INSERT INTO repair_system.community (communityId, communityName, communityAddress, startTime, finishTime) VALUES (13330001, '海城', '江宁区清水亭10号', '2022-04-19 00:00:00', null);
