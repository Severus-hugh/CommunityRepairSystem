INSERT INTO repair_system.message (messageID, title, content, announceTime) VALUES (2104170847, '凤南小区北区水管破裂已修复', '凤南小区北区6栋附近水管破裂已于4月17日上午修复', '2022-04-17 11:47:00');
INSERT INTO repair_system.message (messageID, title, content, announceTime) VALUES (2104170848, '凤南小区近期维护性停水', '凤南小区将于4月19号8点到12点计划性停水', '2022-04-18 00:00:00');
INSERT INTO repair_system.message (messageID, title, content, announceTime) VALUES (2104170849, '湖滨小区南区灯修复', '湖滨小区南区4号楼2单元楼宇门附近灯已修复', '2022-04-21 09:00:00');
INSERT INTO repair_system.message (messageID, title, content, announceTime) VALUES (2104170850, '凤凰花园近期将进行天然气检查', '凤凰花园小区将于4月23号和4月24号两天进行燃气管道的检查，需要检查的居民请注意。', '2022-04-21 12:00:00');
INSERT INTO repair_system.message (messageID, title, content, announceTime) VALUES (2104170851, '海城小区所有电梯已检修完毕', '海城小区所有电梯已于今日16点检修完毕，无异常，请各位用户放心使用。', '2022-04-25 16:30:30');
INSERT INTO repair_system.message (messageID, title, content, announceTime) VALUES (2104170863, '111', '1111', '2022-5-19 20:18:39');
