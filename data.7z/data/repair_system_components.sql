INSERT INTO repair_system.components (componentID, componentName, componentCompany, componentField, componentPrice) VALUES (1134220001, '塑料软管（1米）', '万和生产公司', '2001', 5);
