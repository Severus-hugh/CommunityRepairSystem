INSERT INTO repair_system.fengnancommunity (householdID, householdName) VALUES (300001, '凤南小区1号楼');
INSERT INTO repair_system.fengnancommunity (householdID, householdName) VALUES (300002, '凤南小区2号楼');
INSERT INTO repair_system.fengnancommunity (householdID, householdName) VALUES (300003, '凤南小区3号楼');
INSERT INTO repair_system.fengnancommunity (householdID, householdName) VALUES (300004, '凤南小区4号楼');
INSERT INTO repair_system.fengnancommunity (householdID, householdName) VALUES (300005, '凤南小区5号楼');
INSERT INTO repair_system.fengnancommunity (householdID, householdName) VALUES (300006, '凤南小区6号楼');
INSERT INTO repair_system.fengnancommunity (householdID, householdName) VALUES (300007, '凤南小区7号楼');
INSERT INTO repair_system.fengnancommunity (householdID, householdName) VALUES (300008, '凤南小区8号楼');
